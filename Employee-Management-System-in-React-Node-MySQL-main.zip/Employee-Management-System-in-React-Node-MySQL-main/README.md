# Employee-Management-System-in-React-Node-MySQL
The first two folders you see (Front-end and Server) these are the older version of employee management system project.

The Updated employee management system project is in the newly created folder.

Fist part video on **YouTube**: https://youtu.be/IKQQIYDfyPc

Second Part: https://youtu.be/6a4B7ev3vd0

Support me: https://www.buymeacoffee.com/codewithyousaf

https://codewithyousaf.blogspot.com/
